### Create a Paint Bucket Tool in HTML5 and JavaScript

Article located at: http://wmalone.com/bucket

![My image](http://www.williammalone.com/articles/html5-canvas-javascript-paint-bucket-tool/images/canvas-image.png)